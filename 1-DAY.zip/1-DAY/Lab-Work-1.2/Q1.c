#include <stdio.h>

 int main()
{
    printf("Name      : Chintan Rathod\n");
    printf("Age       : 22\n");
    printf("Institute : Red & White Multimedia Edu.");
}