#include <stdio.h>

int main(){

    int r;
    const float pi=3.14;
    float ans;

    printf("Enter Radius : ");
    scanf("%d",&r);

    ans=2*pi*r;

    printf("Answer is : %.3f",ans);
    


}