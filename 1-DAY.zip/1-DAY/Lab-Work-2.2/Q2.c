#include <stdio.h>

int main(){
    
    int l, ans;


    printf("Enter length : ");
    scanf("%d",&l);

    ans =l*l;

    printf("Answer is : %d",ans);

}