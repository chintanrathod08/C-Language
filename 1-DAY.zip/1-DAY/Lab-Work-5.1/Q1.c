#include<stdio.h>
int main ()
{

    int x,y;

    printf("Enter value of x =");
    scanf("%d",&x);
     printf("Enter value of y =");
    scanf("%d",&y);

    if(x<y)
    {
        printf("First number : 8");
    }
    else
    {
        printf("Second number : 3");
    }


}