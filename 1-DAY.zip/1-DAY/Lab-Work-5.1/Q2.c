#include<stdio.h>
int main()
{
    int a;
    printf("Enter Value of a=");
	scanf("%d",&a);

	if(a>0)
	{
		printf("a is positive");
	}
	else if(a<0)
	{
		printf("b is negative");
	}
	else
	{
		printf("This number is Neutral");

	}

}