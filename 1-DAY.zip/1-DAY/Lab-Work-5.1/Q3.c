#include <stdio.h>
int main()
{
    float a = 90, b = 82, c = 78 , Total;

    printf("Enter maths   marks: \n");
    printf("Enter english marks: \n");
    printf("Enter science marks: \n");

    Total = (a+b+c)/3;

    printf("Average mark: %.2f",Total);

    
}