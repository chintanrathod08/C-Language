#include <stdio.h>

int main(){

    int x,y;

    printf("Enter X Value : ");
    scanf("%d",&x);

    printf("Enter Y Value : ");
    scanf("%d",&y);

    printf("Adition of X + Y = %d\n", x + y);
    printf("Subtraction of x - Y = %d\n", x - y);
    printf("Multiplication of x * Y = %d\n", x * y);
    printf("Divition of x / Y = %d\n", x / y);
    printf("Modul of x % Y = %d\n", x % y);

}